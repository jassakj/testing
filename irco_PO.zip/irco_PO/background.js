chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log('Received message:', message);
    if (message.command === "copy_text") {
      chrome.tabs.query({}, (tabs) => {
        let found = false;
        for (let tab of tabs) {
          console.log('Checking tab:', tab.url);
          if (tab.url && tab.url.startsWith("https://irco.p2p.basware.com/ap/invoice-viewer?srcid=")) {
            found = true;
            console.log('Found matching tab:', tab.url);
            chrome.scripting.executeScript({
              target: { tabId: tab.id },
              files: ['content.js']
            }, () => {
              console.log('Executed content script on tab:', tab.id);
              sendResponse({ result: "Script executed" });
            });
            break;
          }
        }
        if (!found) {
          console.log('No matching tab found');
          sendResponse({ result: "not found" });
        }
      });
      return true; // Indicates that sendResponse will be called asynchronously
    }
  });
  
  chrome.commands.onCommand.addListener((command) => {
    if (command === "copy_text") {
      chrome.tabs.query({}, (tabs) => {
        let found = false;
        for (let tab of tabs) {
          console.log('Checking tab:', tab.url);
          if (tab.url && tab.url.startsWith("https://irco.p2p.basware.com/ap/invoice-viewer?srcid=")) {
            found = true;
            console.log('Found matching tab:', tab.url);
            chrome.scripting.executeScript({
              target: { tabId: tab.id },
              files: ['content.js']
            });
            break;
          }
        }
        if (!found) {
          console.log('No matching tab found');
        }
      });
    }
  });
  