document.getElementById('copyButton').addEventListener('click', () => {
  console.log('Button clicked, sending message to background script');
  chrome.runtime.sendMessage({ command: 'copy_text' }, (response) => {
    if (chrome.runtime.lastError) {
      console.error(chrome.runtime.lastError.message);
    } else {
      console.log('Response from background:', response.result);
    }
  });
});
