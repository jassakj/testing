// Function to wait for an element to be present in the DOM
function waitForElement(selector, timeout = 10000) {
  return new Promise((resolve, reject) => {
    const startTime = Date.now();
    const interval = setInterval(() => {
      const element = document.querySelector(selector);
      if (element) {
        clearInterval(interval);
        resolve(element);
      } else if (Date.now() - startTime > timeout) {
        clearInterval(interval);
        reject(new Error(`Timeout waiting for element with selector: ${selector}`));
      }
    }, 100); // Check every 100ms
  });
}

// Function to extract text content from a single .textLayer element
function extractTextFromTextLayer(textLayer) {
  // Find all text nodes within the .textLayer element
  const walker = document.createTreeWalker(textLayer, NodeFilter.SHOW_TEXT, null, false);
  let textContent = '';

  // Iterate through text nodes and concatenate text content
  while (walker.nextNode()) {
    const node = walker.currentNode;
    textContent += node.textContent.trim() + '\n';
  }

  // Resolve with the extracted text content
  return textContent.trim();
}

// Function to extract text content from all .textLayer elements
function extractTextFromAllTextLayers() {
  try {
    // Find all .textLayer elements directly in the document
    const textLayers = document.querySelectorAll('.textLayer');
    if (!textLayers.length) {
      // If no .textLayer elements found directly, check within iframe
      return waitForElement('iframe[src*="pdfjs-22.9/web/viewer.html"]')
        .then(iframe => {
          const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
          const textLayersInsideIframe = iframeDoc.querySelectorAll('.textLayer');
          if (!textLayersInsideIframe.length) {
            throw new Error('No .textLayer elements found inside iframe');
          }

          const allTextPromises = [];

          // Iterate through .textLayer elements inside iframe and extract text content
          textLayersInsideIframe.forEach(textLayer => {
            const textPromise = Promise.resolve(extractTextFromTextLayer(textLayer));
            allTextPromises.push(textPromise);
          });

          // Return a promise that resolves with text contents from all .textLayer elements
          return Promise.all(allTextPromises);
        });
    }

    const allTextPromises = [];

    // Iterate through .textLayer elements directly in the document and extract text content
    textLayers.forEach(textLayer => {
      const textPromise = Promise.resolve(extractTextFromTextLayer(textLayer));
      allTextPromises.push(textPromise);
    });

    // Return a promise that resolves with text contents from all .textLayer elements
    return Promise.all(allTextPromises);
  } catch (err) {
    return Promise.reject(err);
  }
}

// Function to validate 11234567 pattern
function validate(pos) {
  const PO = pos.match(/(?<![0-9])1[0-2][0-9]{6}/g) || [];

  // Check for duplicates
  const newPOs = [...new Set(PO)];

  return newPOs.join(',');
}

// Function to validate JG00013327 pattern
function validate_JG(gm) {
  const JG = gm.match(/(JG|GM)(000)?([0-9]{1})?(\d{4})/gi) || [];

  const JGlist = JG.map(rawJG => {
    const [, g1, g2, g3, g4] = rawJG.match(/(JG|GM)(000)?([0-9]{1})?(\d{4})/i);

    if (g2) {
      return `${g1.toUpperCase()}${g2}${g3 || '0'}${g4}`;
    } else {
      return `${g1.toUpperCase()}000${g3 || '0'}${g4}`;
    }
  });

  // Check for duplicates
  const newJGs = [...new Set(JGlist)];

  return newJGs.join(',');
}

// Function to process the extracted text
function processText(text) {
  const cpo = validate(text);
  const cjg = validate_JG(text);

  return `${cpo},${cjg}`;
}

// Extract text content from all .textLayer elements
extractTextFromAllTextLayers()
  .then(textContents => {
    // Combine all text contents into a single string
    const combinedText = textContents.join('\n\n');
    console.log('Extracted text:', combinedText);

    // Process the combined text
    const processedText = processText(combinedText);
    console.log('Processed text:', processedText);

    // Copy processed text to clipboard
    navigator.clipboard.writeText(processedText).then(() => {
      console.log("Processed text copied to clipboard:", processedText);
    }).catch(err => {
      console.error('Could not copy text: ', err);
    });
  })
  .catch(err => {
    console.error('Error extracting text:', err);
  });
