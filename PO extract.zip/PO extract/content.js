chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    if (request.getText) {
      const textContent = getTextContent();
      if (textContent) {
        navigator.clipboard.writeText(textContent).then(() => {
          console.log("Text copied to clipboard!");
        }, () => {
          console.error("Failed to copy text to clipboard!");
        });
      } else {
        console.log("No text found on this page.");
      }
      sendResponse(textContent);
    }
  });
  
  function getTextContent() {
    // Replace this function with your logic to extract text from the page.
    // You can use techniques like DOM manipulation or libraries like jQuery.
    // This example retrieves all text nodes and combines them.
    const allText = [];
    const textNodes = document.querySelectorAll("*");
    for (const node of textNodes) {
      if (node.nodeType === Node.TEXT_NODE) {
        allText.push(node.textContent.trim());
      }
    }
    return allText.join("\n");
  }
  
  // Send a message to background script when the page loads
  chrome.runtime.sendMessage({ getText: true });
  